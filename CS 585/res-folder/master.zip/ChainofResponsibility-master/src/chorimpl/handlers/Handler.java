package chorimpl.handlers;

import chorimpl.Milk;

/**
 * Created by misko on 17.1.2015.
 */
public interface Handler {
    public void handle(Milk milk);
}
